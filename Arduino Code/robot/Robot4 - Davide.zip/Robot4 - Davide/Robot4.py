import picamera
import picamera.array
import sys
import numpy as np
debug = 1
#Start log debug file
if debug:
    rowmatrix=open('debug/log/rowMatrix.txt', 'w+') #matrice grezza con valori 0,1.
    withoutNoise = open('debug/log/withoutNoise.txt', 'w+')
arrayImg = []
arrayFilt = [[0 for x in range(101)] for y in range(101)]

with picamera.PiCamera() as camera:
    camera.resolution = (100, 100)
    with picamera.array.PiRGBArray(camera) as output:
        camera.capture(output, 'rgb')
        if debug:
            camera.capture('debug/img/rowImg.jpg')
        arrayImg = output.array.copy()
    #popolo array rgb con l'immagine catturata
    for y in range (0,100):
        for x in range (0,100):
            if arrayImg[y,x,0] < 20 and arrayImg[y,x,1] < 20 and arrayImg[y,x,2] < 20:
                arrayImg[y,x] = 1
            else:
                arrayImg[y,x] = 0
    #definisco i bordi dell'immagine
    lastx = 50
    find = 0
    tmp = 0
    for y in range (0,100):
        x = 0
        if find == 0:
            lastx = 50
        else:
            lastx = tmp 
        find = 0
        exit = 0
        for x in range(lastx,100):
            if arrayImg[y,x,0] == 1:
                arrayFilt[y][x] = 1
                if find == 0:
                    find = 1
                tmp = x
                exit = 0
            else:
                exit = exit + 1
            if exit > 3:
                break
                print("Esco forzato")
        for x in range (lastx,0,-1):
            if arrayImg[y,x,0] == 1:
                if find == 0:
                    find = 1
                arrayFilt[y][x] = 1
                tmp = x
            else:
                exit = exit + 1
            if exit > 3:
                break
                exit = 0
    #debug
    if debug:
        for y in range (0,100):
            rowmatrix.write("\n")
            withoutNoise.write("\n")
            for x in range (0,100):
                rowmatrix.write(np.array_str(arrayImg[x,y,0]))
                rowmatrix.write(" ")
                withoutNoise.write(str(arrayFilt[y][x]))
                withoutNoise.write(" ")
        rowmatrix.close()
        withoutNoise.close()
        print("end writing file")
    