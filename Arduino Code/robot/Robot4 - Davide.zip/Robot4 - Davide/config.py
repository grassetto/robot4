import picamera
import picamera.array
import sys
import numpy as np

row_array = []
config = open('config/config.txt', 'w+')
black = 0
with picamera.PiCamera() as camera:
    camera.resolution = (128, 112)
    with picamera.array.PiRGBArray(camera) as output:
        camera.capture(output, 'rgb')
        camera.capture('captured_image.jpg')
        row_array = camera.array.copy()
        
        for y in range(0,128):
            for x in range(0,112):
                